#!/usr/bin/env python3
"""
Build the two fixed 1024-token prompts as token ids -> token_ids.json

Texts are the openings of two public-domain Project Gutenberg books, taken
from a marker sentence to the end of file, then tokenized with the
checkpoint's own tokenizer and truncated to 1024 ids. No BOS is added.
"""
import json
import pathlib
import sys

import transformers

MODEL = "RedHatAI/gemma-4-31B-it-FP8-block"
MAX_LEN = 1024

SOURCES = [
    ("prompt_0", "pg1342.txt", "It is a truth universally acknowledged"),
    ("prompt_1", "pg1228.txt", "When on board H.M.S."),
]

# Reference values from the task spec. Any mismatch -> stop and ask for the
# canonical token_ids.json rather than guessing.
EXPECTED = {
    "prompt_0": {"first6": [1509, 563, 496, 9043, 69127, 30285],
                 "last6": [531, 775, 236764, 768, 12571, 1288],
                 "sum": 40724524},
    "prompt_1": {"first6": [4420, 580, 3905, 640, 236761, 236792],
                 "last6": [506, 10345, 529, 2953, 30348, 107],
                 "sum": 41679672},
}


def excerpt(path, marker):
    text = pathlib.Path(path).read_text(encoding="utf-8")  # universal newlines: CRLF -> LF
    return text[text.index(marker):]


def main() -> int:
    tok = transformers.AutoTokenizer.from_pretrained(MODEL)
    prompts = []
    ok = True
    for name, path, marker in SOURCES:
        text = excerpt(path, marker)
        ids = tok(text, add_special_tokens=True, truncation=True,
                  max_length=MAX_LEN).input_ids
        ids = [int(x) for x in ids]

        exp = EXPECTED[name]
        checks = {
            "length==1024": len(ids) == MAX_LEN,
            "first6": ids[:6] == exp["first6"],
            "last6": ids[-6:] == exp["last6"],
            "sum": sum(ids) == exp["sum"],
        }
        print(f"{name}: len={len(ids)} first6={ids[:6]} last6={ids[-6:]} sum={sum(ids)}")
        for k, v in checks.items():
            print(f"    {k:<14} {'OK' if v else 'MISMATCH'}")
        ok &= all(checks.values())
        prompts.append({"name": name, "token_ids": ids})

    if not ok:
        print("\nTOKEN ID MISMATCH against the spec. Not writing token_ids.json. "
              "Ask for the canonical token_ids.json instead of guessing.", file=sys.stderr)
        return 1

    with open("token_ids.json", "w") as f:
        json.dump({"model": MODEL, "prompts": prompts}, f)
    print("\nwrote token_ids.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
